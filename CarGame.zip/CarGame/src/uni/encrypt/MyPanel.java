package uni.encrypt;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.ArrayList;

public class MyPanel extends JPanel {
    private boolean[][] movements;
    private boolean ongoing = true;

    private int[] lastLine = new int[]{450, 300, 500, 300};

    public MyPanel(boolean[][] movements) {
        this.movements = movements;
        InputMap im = getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap ap = getActionMap();
        putKeyBinding(im, ap, Movement.DOWN);
        putKeyBinding(im, ap, Movement.UP);
        putKeyBinding(im, ap, Movement.LEFT);
        putKeyBinding(im, ap, Movement.RIGHT);
    }

    private Ellipse2D getEllipseFromCenter(double x, double y, double width, double height) {
        double newX = x - width / 2.0;
        double newY = y - height / 2.0;

        Ellipse2D ellipse = new Ellipse2D.Double(newX, newY, width, height);

        return ellipse;
    }

    //   @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g1 = (Graphics2D) g;
        try {
            /**
             * Draw racetrack
             */
            Area raceTrack = new Area(getEllipseFromCenter(500, 500, 1300, 800));
            raceTrack.subtract(new Area(getEllipseFromCenter(500, 500, 800, 300)));
            //raceTrack.subtract(new Area(new Rectangle2D.Double(250, 230, 10, 150)));
            raceTrack.subtract(new Area(new Rectangle2D.Double(125, 175, 10, 150)));
            g1.fill(raceTrack);

            MoveAmount moveAmount = getMoveAmountForAI();
            int newX2 = lastLine[0] + moveAmount.getMoveX();
            int newY2 = lastLine[1] + moveAmount.getMoveY();
            int newX1 = lastLine[2] + moveAmount.getMoveX();
            int newY1 = lastLine[3] + moveAmount.getMoveY();

            Path2D car = CarUtils.getCar(newX1, newY1, newX2, newY2, 10);
            Area carArea = new Area(car);
            carArea.add(raceTrack);
            carArea.subtract(raceTrack);

            lastLine[0] = newX1;
            lastLine[1] = newY1;
            lastLine[2] = newX2;
            lastLine[3] = newY2;

            g1.setPaint(Color.BLUE);
            g1.fill(car);
            Thread.sleep(17);
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted");
        }

        drawGoal(g1);
        if (ongoing) {
            repaint();
        }
    }

    private void drawGoal(Graphics2D g1) {
        Shape coordShape = new Rectangle2D.Double(0, 350, 50, 50);
        g1.setPaint(Color.RED);
        g1.fill(coordShape);
    }

    private void putKeyBinding(InputMap inputMap, ActionMap actionMap, Movement movement) {
        inputMap.put(KeyStroke.getKeyStroke(movement.getKeycode(), 0, false), movement + "P");
        inputMap.put(KeyStroke.getKeyStroke(movement.getKeycode(), 0, true), movement + "R");
    }

    private int counter = 0;

    private MoveAmount getMoveAmountForAI() {
        MoveAmount moveAmount = new MoveAmount();
        try {

            moveAmount.setMoveX(movements[counter][0] ? 5 : -5);
            moveAmount.setMoveY(movements[counter][1] ? 5 : -5);

        } catch (ArrayIndexOutOfBoundsException e) {
            ongoing = false;
        }
        counter++;
        return moveAmount;
    }

}
