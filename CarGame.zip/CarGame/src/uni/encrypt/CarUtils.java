package uni.encrypt;


import java.awt.geom.Path2D;

public class CarUtils {
    public static Path2D oldPath;
    public static Path2D getCar(int x0, int y0, int x1, int y1, int halfHeight) {
        double k;
        try {
            k = ((y1-y0)*(y1-y0) + 1.0 - 1.0)/((x1-x0)*(x1-x0) + 1.0 - 1.0) + 1;
        } catch (ArithmeticException e) {
            return oldPath;
        }
        double B = (y0*k + Math.sqrt(y0*y0*k*k + halfHeight*halfHeight*k - y0*y0*k*k))/k;
        double A = -(B-y0)*(y1-y0)/(x1-x0) + x0;
        double[] p1 = {A, B};
        double[] p2= {p1[0] + x1-x0, p1[1] + y1-y0};
        double[] p3 = {p2[0] + 2*(x0-p1[0]), p2[1] + 2*(y0-p1[1])};
        double[] p4 = {p3[0] + x0-x1, p3[1] + y0-y1};
        Path2D path2D = new Path2D.Double();
        path2D.moveTo(p1[0], p1[1]);
        path2D.lineTo(p2[0], p2[1]);
        path2D.lineTo(p3[0], p3[1]);
        path2D.lineTo(p4[0], p4[1]);

        Path2D newPath = new Path2D.Double();
        newPath.moveTo(x1, y1);
        newPath.lineTo(x0, y0);
        newPath.lineTo(p1[0], p1[1]);
        newPath.closePath();
        path2D.closePath();
        oldPath = path2D;
        return path2D;
    }
}
