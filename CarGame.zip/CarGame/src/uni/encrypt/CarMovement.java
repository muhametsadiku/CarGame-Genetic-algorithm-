package uni.encrypt;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

public class CarMovement {
    public boolean[][] getMovements() {
        return movements;
    }

    private double distanceToGoal = 0;

    private boolean[][] movements;
    private int[] lastLine = new int[] {450, 300, 500, 300};

    private Ellipse2D getEllipseFromCenter(double x, double y, double width, double height) {
        double newX = x - width / 2.0;
        double newY = y - height / 2.0;

        Ellipse2D ellipse = new Ellipse2D.Double(newX, newY, width, height);

        return ellipse;
    }

    public CarMovement(boolean[][] movements) {
        this.setDistanceToGoal();
        this.movements = movements;
    }

    private void setDistanceToGoal() {
        int goalX = 0;
        int goalY = 350;
        this.distanceToGoal = Math.sqrt((goalX-lastLine[2])*(goalX-lastLine[2]) + (goalY - lastLine[3])*(goalY - lastLine[3]));
    }

    public double getDistanceToGoal() {
        return distanceToGoal;
    }

    public void printDistanceToGoal() {
        System.out.println("Distanca prej qellimit eshte: " + getDistanceToGoal());
    }

    public void move() {
        for (int i = 0; i < movements.length; i++) {
            try {
                Area raceTrack = new Area(getEllipseFromCenter(500, 500, 1300, 800));
                raceTrack.subtract(new Area(getEllipseFromCenter(500, 500, 800, 300)));

                MoveAmount moveAmount = getMoveAmountForAI(i);
                int newX2 = lastLine[0] + moveAmount.getMoveX();
                int newY2 = lastLine[1] + moveAmount.getMoveY();
                int newX1 = lastLine[2] + moveAmount.getMoveX();
                int newY1 = lastLine[3] + moveAmount.getMoveY();

                Path2D car = CarUtils.getCar(newX1, newY1, newX2, newY2, 10);

                // kontrollon a eshte jashte fushes
                Area carArea = new Area(car);
                
                carArea.add(raceTrack);
                carArea.subtract(raceTrack);
                if (!carArea.isEmpty()) {
                    setDistanceToGoal();
                    return;
                }
                
                lastLine[0] = newX1;
                lastLine[1] = newY1;
                lastLine[2] = newX2;
                lastLine[3] = newY2;
            } catch (Exception e) {
                System.out.println("Thread interrupted");
                setDistanceToGoal();
                return;
            }
        }
        //setFitness
        setDistanceToGoal();
    }

    private MoveAmount getMoveAmountForAI(int i) {
        MoveAmount moveAmount = new MoveAmount();
        moveAmount.setMoveX(movements[i][0] ? 5 : -5);
        moveAmount.setMoveY(movements[i][1] ? 5 : -5);
        return moveAmount;
    }
}
