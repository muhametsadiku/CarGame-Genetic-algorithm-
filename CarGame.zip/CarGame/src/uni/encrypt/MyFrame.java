package uni.encrypt;

import javax.swing.*;
import java.awt.*;

public class MyFrame extends JFrame {
    public MyFrame() throws HeadlessException {
        setVisible(true);
        setSize(2000, 2000);
    }
}
