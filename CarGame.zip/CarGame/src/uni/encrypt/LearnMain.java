package uni.encrypt;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;


public class LearnMain {
    public static int MOVEMENTS = 500;
    public static int THREADS = 100;
    public static int POP = 100;
    public static int GENERATIONS = 10;


    public static void main(String[] args) {
    	long start = System.currentTimeMillis();
        // gjenerimi i popullates origjinale
        List<CarMovement> carMovements = new ArrayList<>();
        for (int i = 0; i < POP; i++) {
            boolean[][] movements = new boolean[MOVEMENTS][2];
            for (int j = 0; j < MOVEMENTS; j++) {
                //random false/true

                movements[j][0] = !(Math.random() < 0.5);
                movements[j][1] = !(Math.random() < 0.5);
            }
            CarMovement carMovement = new CarMovement(movements);
            carMovements.add(carMovement);
        }

        // krijimi i gjeneratave te reja
        for (int i = 0; i < GENERATIONS; i++) {
            System.out.println("Generation: " + i + " started!");
            carMovements = getNewGeneration(carMovements);
            System.out.println("Generation: " + i + " finished!");
        }
        moveCars(carMovements);

        carMovements.sort((carMovement1, carMovement2) -> {
            if ((carMovement2.getDistanceToGoal() - carMovement1.getDistanceToGoal()) > 0) {
                return -11;
            } else if ((carMovement2.getDistanceToGoal() - carMovement1.getDistanceToGoal()) < 0) {
                return 1;
            } else {
                return 0;
            }
        });
        long end = System.currentTimeMillis();
        System.out.println("Koha e duhur per ta gjetur rrugen eshte: " + (end-start) + " milisekonda");
        carMovements.get(0).printDistanceToGoal();

        new MyFrame().getContentPane().add(new MyPanel(carMovements.get(0).getMovements()));
    }

    public static void moveCars(List<CarMovement> carMovements) {
        ExecutorService executorService = Executors.newFixedThreadPool(THREADS);
        //kalkulimi i fitnesit per qdo element
        for (int i = 0; i < POP; i++) {
            int index = i;
            Thread thread = new Thread(() -> {
                // rreshti ma i rendsishem
                carMovements.get(index).move();
            });
            executorService.submit(thread);
        }

        try {
            executorService.shutdown();
            if (!executorService.awaitTermination(1, TimeUnit.MINUTES)) {
                System.out.println("Not done in one minute!");
            }
        } catch (InterruptedException e) {
            System.out.println("INTERRUPTED");
        }
    }

    public static List<CarMovement> getNewGeneration(List<CarMovement> carMovements) {
        moveCars(carMovements);
        //caktimi i probabilitetit ne baze te fitnesit
        double minFitness = carMovements.stream().mapToDouble(carMovement1 -> carMovement1.getDistanceToGoal()).max().getAsDouble();
        double probabilitySum = carMovements.stream().mapToDouble(carMovement -> minFitness - carMovement.getDistanceToGoal()).sum();
        Map<CarMovement, Double> probabilityForCar = new HashMap<>();
        List<Double> probabilities = carMovements.stream().map(carMovement -> (minFitness - carMovement.getDistanceToGoal()) / probabilitySum).collect(Collectors.toList());
        for (int i = 0; i < probabilities.size(); i++) {
            probabilityForCar.put(carMovements.get(i), probabilities.get(i));
        }

        // zgjedhja e prinderve ne baze te probabilitetit dhe krijimi i gjenerates te re
        Map<CarMovement, Double> sortedProbabilityForCar = new LinkedHashMap<>();
        probabilityForCar.entrySet().stream().sorted(Map.Entry.comparingByValue((((c1, c2) -> -1*(c1).compareTo(c2))))).forEachOrdered(x -> sortedProbabilityForCar.put(x.getKey(), x.getValue()));

        List<CarMovement> newGeneration = new ArrayList<>();
        for (int j = 0; j < POP/2; j++) {
            CarMovement parentOne = getParent(probabilities, sortedProbabilityForCar);
            CarMovement parentTwo = getParent(probabilities, sortedProbabilityForCar);

            boolean[][] newMovements = new boolean[MOVEMENTS][2];
            //child one
            for (int i = 0; i < MOVEMENTS/2; i++) {
                newMovements[i][1] = parentOne.getMovements()[i][1];
                newMovements[i][0] = parentOne.getMovements()[i][0];
            }

            for (int i = MOVEMENTS/2; i < MOVEMENTS; i++) {
                newMovements[i][1] = parentTwo.getMovements()[i][1];
                newMovements[i][0] = parentTwo.getMovements()[i][0];
            }
            newGeneration.add(new CarMovement(newMovements));
            
            //child two
            boolean [][] newMovements2 = new boolean[MOVEMENTS][2];
            for(int i = 0; i < MOVEMENTS/2; i++) {
            	
            	newMovements2[i][1] = parentTwo.getMovements()[i][1];
            	newMovements2[i][0] = parentTwo.getMovements()[i][0];
            	
            }
            
            for(int i = MOVEMENTS/2; i < MOVEMENTS; i++) {
            	
            	newMovements2[i][1] = parentOne.getMovements()[i][1];
                newMovements2[i][0] = parentOne.getMovements()[i][0];
            	
            }
            newGeneration.add(new CarMovement(newMovements2));
            
        }
        return newGeneration;
    }

    private static CarMovement getParent(List<Double> probabilities, Map<CarMovement, Double> sortedProbabilityForCar) {
        double rand = Math.random();
        double sum = 0;
        CarMovement parent = null;
        do {
            for (int i = 0; i < probabilities.size(); i++) {
                CarMovement car = (CarMovement) sortedProbabilityForCar.keySet().toArray()[i];
                if (sum <= rand && rand <= sum + sortedProbabilityForCar.get(car)) {
                    parent = car;
                }
                sum += sortedProbabilityForCar.get(car);
            }
        } while (parent == null);
        return parent;
    }
}

